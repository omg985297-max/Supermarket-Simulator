# Supermarket Simulator 3D
First-person browser supermarket prototype.

## Run
Open `index.html` in a modern browser with internet access (Three.js loads from jsDelivr).

## GitHub Codespaces
Run `python3 -m http.server 8000` in the terminal, then open port 8000 in the Ports tab.

## Controls
- WASD: walk
- Mouse: look around (click the game window to capture mouse)
- E: interact with shelf, checkout, stock delivery, or store upgrade
- Shift: move faster

Progress cash and stock are saved in this browser. This is a prototype, not a finished commercial release; it still needs more testing, sound, expanded gameplay, and platform SDK integration before publishing.
